BANKA ŞABLON AI - ANDROID UYGULAMA PROJESİ

Bu paket, telefonda çalışan native Android uygulama kaynak dosyasıdır.
Claude API doğrudan Android uygulama içinden çağrılır; CORS/server/Termux gerekmez.

Özellikler:
- Galeriden birden fazla dekont resmi seçme
- Claude Vision ile resmi analiz etme
- Başlıkları ve karşısındaki bilgileri aynı sırayla çıkarma
- HTML şablon kaydetme
- PNG şablon kaydetme
- API key telefonda saklanır

APK üretmek için:
1) Android Studio aç.
2) Open Project ile bu klasörü seç: BankaSablonAndroid
3) Build > Build Bundle(s) / APK(s) > Build APK(s)
4) Oluşan APK'yı telefona kur.

Not:
Bu ortamda Android SDK/Gradle olmadığı için imzalı APK derleyemiyorum; ama proje APK üretmeye hazırdır.
